const $ = (id) => document.getElementById(id);

function fmtPoints(n) {
  return Number(n || 0).toLocaleString();
}

function fmtTime(ts) {
  if (!ts) return "-";
  const d = new Date(Number(ts) * 1000);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function escapeHtml(s) {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

async function api(path, options) {
  const resp = await fetch(path, {
    credentials: "same-origin",
    ...options,
  });
  let data = {};
  try {
    data = await resp.json();
  } catch (e) {
    data = {};
  }
  if (!resp.ok && data.status === "error") {
    throw new Error(data.message || "请求失败");
  }
  return data;
}

function showLogin() {
  $("login-view").classList.remove("hidden");
  $("authed-view").classList.add("hidden");
  $("login-info").textContent = "";
}

function showAuthed(uid) {
  $("login-view").classList.add("hidden");
  $("authed-view").classList.remove("hidden");
  $("login-info").textContent = `已登录：${escapeHtml(uid)}`;
}

async function loadMe() {
  try {
    const data = await api("/api/me");
    if (data.status === "ok") {
      showAuthed(data.data.uid);
      const box = $("my-uid-code");
      if (box) box.value = (data.data && data.data.uid_code) || "";
      await loadBindRequests();
      await Promise.all([loadMyPoints(), loadMyImages(), loadRedeemHistory(), loadLeaderboard()]);
    } else {
      showLogin();
    }
  } catch (e) {
    showLogin();
  }
}

async function bindLogin() {
  $("login-btn").addEventListener("click", async () => {
    const username = $("login-username").value.trim();
    const password = $("login-password").value;
    const out = $("login-result");
    if (!username || !password) {
      out.textContent = "请输入用户名和密码。";
      return;
    }
    out.textContent = "登录中…";
    try {
      const data = await api("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      out.textContent = "";
      await loadMe();
    } catch (e) {
      out.textContent = e.message;
    }
  });
  $("login-password").addEventListener("keydown", (e) => {
    if (e.key === "Enter") $("login-btn").click();
  });
}

async function loadMyPoints() {
  const data = await api("/api/me/points");
  const d = data.data || {};
  const out = $("my-points");
  if (!d.found) {
    out.textContent = "暂无积分数据（可能尚未同步）。";
    return;
  }
  const u = d.user;
  out.innerHTML = `当前积分：<strong>${fmtPoints(u.points)}</strong><br/><span class="muted">用户ID：${escapeHtml(u.user_id)}</span>`;
}

function bindRedeem() {
  $("redeem-btn").addEventListener("click", async () => {
    const code = $("redeem-code").value.trim();
    const out = $("redeem-result");
    if (!code) {
      out.textContent = "请输入兑换码。";
      return;
    }
    out.textContent = "提交中…";
    try {
      const data = await api("/api/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code }),
      });
      out.textContent = data.message || "兑换已提交";
      $("redeem-code").value = "";
      await loadRedeemHistory();
    } catch (e) {
      out.textContent = e.message;
    }
  });
}

async function loadRedeemHistory() {
  const data = await api("/api/me/redeem_result");
  const items = (data.data && data.data.items) || [];
  const box = $("redeem-history");
  box.innerHTML = "";
  if (!items.length) {
    box.innerHTML = '<p class="hint">暂无兑换记录。</p>';
    return;
  }
  items.forEach((item) => {
    const div = document.createElement("div");
    div.className = "history-item";
    const tag = item.status === "done" ? "✅ 成功" : item.status === "failed" ? "❌ 失败" : "⏳ 处理中";
    div.innerHTML = `<span class="code">${escapeHtml(item.code)}</span> ${tag} ${escapeHtml(item.message || "")}<br/><span class="hint">${fmtTime(item.created_at)}</span>`;
    box.appendChild(div);
  });
}

function bindUpload() {
  $("upload-btn").addEventListener("click", async () => {
    const file = $("upload-file").files[0];
    const out = $("upload-result");
    if (!file) {
      out.textContent = "请选择图片。";
      return;
    }
    const fd = new FormData();
    fd.append("file", file);
    out.textContent = "上传中…";
    try {
      const data = await api("/api/upload", { method: "POST", body: fd });
      out.textContent = data.message || "上传成功";
      $("upload-file").value = "";
      await loadMyImages();
    } catch (e) {
      out.textContent = e.message;
    }
  });
}

async function loadMyImages() {
  const data = await api("/api/me/images");
  const items = (data.data && data.data.items) || [];
  const grid = $("my-images");
  grid.innerHTML = "";
  if (!items.length) {
    grid.innerHTML = '<p class="hint">暂无图片。</p>';
    return;
  }
  items.forEach((img) => {
    const item = document.createElement("div");
    item.className = "image-item";
    item.innerHTML = `<img src="${escapeHtml(img.url)}" alt="图片" loading="lazy"/><span class="hint">${escapeHtml(img.filename || "")} · ${fmtTime(img.created_at)}</span>`;
    grid.appendChild(item);
  });
}

async function loadLeaderboard() {
  const data = await api("/api/leaderboard?limit=100");
  const items = (data.data && data.data.items) || [];
  const body = $("leaderboard-body");
  body.innerHTML = "";
  if (!items.length) {
    body.innerHTML = '<tr><td colspan="3" class="hint">暂无数据</td></tr>';
    return;
  }
  items.forEach((u) => {
    const medal = u.rank === 1 ? "🥇" : u.rank === 2 ? "🥈" : u.rank === 3 ? "🥉" : String(u.rank);
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${medal}</td><td>${escapeHtml(u.name)}</td><td class="strong">${fmtPoints(u.points)}</td>`;
    body.appendChild(tr);
  });
}

function bindLogout() {
  $("logout-btn").addEventListener("click", async () => {
    await api("/api/logout", { method: "POST" });
    showLogin();
  });
}

async function loadBindRequests() {
  const box = $("bind-list");
  if (!box) return;
  box.innerHTML = '<p class="hint">加载中…</p>';
  try {
    const data = await api("/api/me/bind_requests");
    const items = (data.data && data.data.items) || [];
    if (!items.length) {
      box.innerHTML = '<p class="hint">暂无绑定请求。</p>';
      return;
    }
    const label = { pending: "待确认", confirmed: "已确认", rejected: "已拒绝" };
    box.innerHTML = "";
    items.forEach((it) => {
      const st = label[it.status] || it.status;
      const div = document.createElement("div");
      div.className = "history-item";
      div.setAttribute("data-key", it.key);
      div.innerHTML =
        `<b>${escapeHtml(it.platform || "")}</b> · ${escapeHtml(it.user_name || it.user_id || "")}` +
        `<br/><span class="hint">状态：${escapeHtml(st)}</span>`;
      if (it.status === "pending") {
        const row = document.createElement("div");
        row.className = "row";
        row.innerHTML = '<button class="primary bind-ok">确认</button><button class="ghost bind-no">拒绝</button>';
        div.appendChild(row);
      }
      box.appendChild(div);
    });
  } catch (e) {
    box.innerHTML = `<p class="hint">${escapeHtml(e.message)}</p>`;
  }
}

function bindBindActions() {
  const box = $("bind-list");
  if (box) {
    box.addEventListener("click", async (ev) => {
      const btn = ev.target.closest("button");
      const item = btn ? btn.closest(".history-item") : null;
      if (!btn || !item) return;
      const key = item.getAttribute("data-key");
      const isOk = btn.classList.contains("bind-ok");
      btn.disabled = true;
      try {
        await api(isOk ? "/api/me/bind/confirm" : "/api/me/bind/reject", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ key: key }),
        });
        await loadBindRequests();
      } catch (e) {
        alert(e.message);
      } finally {
        btn.disabled = false;
      }
    });
  }
  const refresh = $("bind-refresh-btn");
  if (refresh) refresh.addEventListener("click", () => void loadBindRequests());
  const copy = $("copy-uid-btn");
  if (copy) {
    copy.addEventListener("click", async () => {
      const box2 = $("my-uid-code");
      try {
        await navigator.clipboard.writeText(box2 ? box2.value : "");
        copy.textContent = "已复制";
      } catch (e) {
        copy.textContent = "请手动复制";
      }
      setTimeout(() => { copy.textContent = "复制"; }, 1500);
    });
  }
}

function bindRegister() {
  const btn = $("register-btn");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    const out = $("register-result");
    const uid = ($("reg-qq") || {}).value ? $("reg-qq").value.trim() : "";
    const verify = ($("reg-cookie") || {}).value ? $("reg-cookie").value.trim() : "";
    const username = ($("reg-username") || {}).value ? $("reg-username").value.trim() : "";
    const password = ($("reg-password") || {}).value ? $("reg-password").value : "";
    if (!uid || !verify || !username || !password) {
      out.textContent = "请把 QQ号、cookieQQ验证码、用户名、密码都填上。";
      return;
    }
    out.textContent = "提交中…";
    try {
      const data = await api("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uid: uid, verify_id: verify, username: username, password: password }),
      });
      out.textContent = data.message || "注册申请已提交，稍后即可登录";
    } catch (e) {
      out.textContent = e.message;
    }
  });
}

function init() {
  bindLogin();
  bindRegister();
  bindBindActions();
  bindRedeem();
  bindUpload();
  bindLogout();
  void loadMe();
}

init();
