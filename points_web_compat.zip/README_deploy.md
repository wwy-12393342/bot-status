# 积分系统公开网站（pythonanywhere 部署）

网站需要登录才能使用。账号由本地 AstrBot 站长创建（`/积分 网站账号 创建 用户名 密码 [用户ID]`），
登录后用户仅能查看自己的积分/图片、上传图片、使用兑换码。

## 文件结构

```
points_web/
├── app.py                # Flask 应用（WSGI 入口指向 app）
├── requirements.txt
├── templates/index.html  # 页面
├── static/
│   ├── app.js
│   ├── style.css
│   └── uploads/          # 用户上传的图片（自动创建）
└── README_deploy.md
```

## 部署到 pythonanywhere

1. 打开 https://www.pythonanywhere.com/ 登录 `wwy12393342`。
2. **Files** → 上传本目录所有文件（app.py、requirements.txt、templates/、static/）。
   建议放到你的 web app 工作目录下（例如 `/home/wwy12393342/points_web/`）。
3. **Web** → 你的 web app → **Code** 区块：
   - 把 WSGI 配置文件的 `application` 改为指向本应用，例如：
     ```python
     import sys
     sys.path.insert(0, "/home/wwy12393342/points_web")
     from app import app as application
     ```
   - 确认 Virtualenv 里已安装 Flask（可用 `pip install -r requirements.txt`）。
4. 设置环境变量（**Web → Environment variables**）：
   - `POINTS_SYNC_TOKEN=你的随机字符串` —— 本地插件同步鉴权
   - `POINTS_SECRET_KEY=另一个随机字符串` —— 网站会话密钥（保证登录 cookie 安全）
5. 点 **Reload**，访问 https://wwy12393342.pythonanywhere.com/ 即可。

## 与本地插件的同步

本地 AstrBot 积分插件需启用并配置：
- `web_sync_enabled = true`
- `web_sync_url = https://wwy12393342.pythonanywhere.com`
- `web_sync_token` 与网站的 `POINTS_SYNC_TOKEN` 一致
- `web_sync_interval`（秒，默认 30）

管理员在机器人处创建网站账号后（见插件 README「公开网站同步」），
账号（含密码哈希）会随同步推送到网站用于登录校验。

本地插件会：
- 定时把积分/图片/**账号**数据 **推送到网站**；
- 拉取网站在线用户提交的 **兑换码 / 上传图片** 请求，在本地真正执行后再把结果同步回网站。
