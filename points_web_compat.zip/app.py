# -*- coding: utf-8 -*-
"""积分系统公开网站（pythonanywhere 部署版）。

需要登录才能使用（账号密码由本地 AstrBot 站长创建并分发）：
- 登录后可查看自己的积分、上传图片、查看自己的图片、使用兑换码；
- 排行榜为公开只读，不展示具体用户ID。

数据通过受保护的同步接口与本地 AstrBot 积分插件双向同步：
- push：本地插件把用户/图片/账号数据推送到本站做快照；
- pull_actions / resolve：本站把用户发起的操作（兑换码/上传）交给本地插件处理。

部署到 pythonanywhere 时，WSGI 入口指向本文件的 ``app``。
"""
from __future__ import annotations

import hashlib
import hmac as hmac_mod
import json
import os
import secrets
import sqlite3
import time
import uuid

from flask import Flask, jsonify, redirect, render_template, request, send_from_directory, session

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "points_web.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")

# 同步 token：请与本地插件配置的 web_sync_token 保持一致
SYNC_TOKEN = os.environ.get("POINTS_SYNC_TOKEN", "")
# 会话密钥：建议设置一个随机值
SECRET_KEY = os.environ.get("POINTS_SECRET_KEY", "")

app = Flask(__name__)
app.secret_key = SECRET_KEY or secrets.token_hex(16)


def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_column(conn: sqlite3.Connection, table: str, column: str, ddl: str) -> None:
    """为旧表补齐缺失的列（幂等迁移）。"""
    cols = {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {ddl}")


def _init_db() -> None:
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    with _db() as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS snapshot (id INTEGER PRIMARY KEY, "
            "users TEXT NOT NULL, images TEXT NOT NULL, updated_at REAL)"
        )
        conn.execute(
            "CREATE TABLE IF NOT EXISTS accounts (username TEXT PRIMARY KEY, "
            "uid TEXT NOT NULL, password_hash TEXT NOT NULL, enabled INTEGER DEFAULT 1)"
        )
        conn.execute(
            "CREATE TABLE IF NOT EXISTS pending_actions (id TEXT PRIMARY KEY, "
            "type TEXT NOT NULL, payload TEXT NOT NULL, status TEXT DEFAULT 'pending', "
            "result TEXT DEFAULT '', created_at REAL)"
        )
        conn.execute(
            "CREATE TABLE IF NOT EXISTS uploads (id TEXT PRIMARY KEY, "
            "owner_uid TEXT, filename TEXT, public_url TEXT, size INTEGER, created_at REAL)"
        )
        # 旧库迁移：补齐新列
        _ensure_column(conn, "accounts", "uid_code", "TEXT DEFAULT ''")
        _ensure_column(conn, "snapshot", "bind_requests", "TEXT")


def _load_snapshot() -> dict:
    with _db() as conn:
        row = conn.execute("SELECT * FROM snapshot LIMIT 1").fetchone()
    if not row:
        return {"users": [], "images": [], "bind_requests": [], "updated_at": 0}
    return {
        "users": json.loads(row["users"] or "[]"),
        "images": json.loads(row["images"] or "[]"),
        "bind_requests": json.loads(
            (row["bind_requests"] if "bind_requests" in row.keys() else "") or "[]"
        ),
        "updated_at": row["updated_at"] or 0,
    }


def _save_snapshot(users: list, images: list, bind_requests=None) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM snapshot")
        conn.execute(
            "INSERT INTO snapshot (id, users, images, updated_at, bind_requests) "
            "VALUES (1, ?, ?, ?, ?)",
            (
                json.dumps(users, ensure_ascii=False),
                json.dumps(images, ensure_ascii=False),
                time.time(),
                json.dumps(bind_requests or [], ensure_ascii=False),
            ),
        )


def _check_sync_token() -> bool:
    if not SYNC_TOKEN:
        return True  # 未配置 token 时放行（仅用于开发）
    auth = request.headers.get("Authorization", "")
    return auth == f"Bearer {SYNC_TOKEN}"


# ---------- 密码哈希（与本地插件一致） ----------

_ITERATIONS = 200_000


def _hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, _ITERATIONS)
    return f"pbkdf2_sha256${_ITERATIONS}${salt.hex()}${digest.hex()}"


def _verify_password(password: str, stored: str) -> bool:
    try:
        algo, iterations, salt_hex, digest_hex = stored.split("$")
        if algo != "pbkdf2_sha256":
            return False
        digest = hashlib.pbkdf2_hmac(
            "sha256", password.encode(), bytes.fromhex(salt_hex), int(iterations)
        )
        return hmac_mod.compare_digest(digest.hex(), digest_hex)
    except (ValueError, TypeError):
        return False


def _sync_accounts(accounts: list) -> None:
    with _db() as conn:
        conn.execute("DELETE FROM accounts")
        for acc in accounts:
            conn.execute(
                "INSERT OR REPLACE INTO accounts (username, uid, uid_code, password_hash, enabled) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    str(acc.get("username", "")),
                    str(acc.get("uid", "")),
                    str(acc.get("uid_code", "")),
                    str(acc.get("password_hash", "")),
                    1 if acc.get("enabled", True) else 0,
                ),
            )


def _get_account(username: str) -> dict | None:
    with _db() as conn:
        row = conn.execute(
            "SELECT * FROM accounts WHERE username=?", (username,)
        ).fetchone()
    if not row:
        return None
    return {
        "username": row["username"],
        "uid": row["uid"],
        "uid_code": (row["uid_code"] if "uid_code" in row.keys() else "") or "",
        "password_hash": row["password_hash"],
        "enabled": bool(row["enabled"]),
    }


# ---------- 登录 / 鉴权 ----------


def _current_uid() -> str | None:
    username = session.get("username")
    if not username:
        return None
    acc = _get_account(username)
    if not acc or not acc["enabled"]:
        return None
    return acc["uid"]


@app.route("/api/login", methods=["POST"])
def api_login():
    body = request.get_json(force=True, silent=True) or {}
    username = str(body.get("username", "")).strip()
    password = str(body.get("password", "")).strip()
    acc = _get_account(username)
    if not acc or not acc["enabled"] or not _verify_password(password, acc["password_hash"]):
        return jsonify({"status": "error", "message": "用户名或密码错误"}), 401
    session["username"] = acc["username"]
    return jsonify(
        {
            "status": "ok",
            "data": {
                "username": acc["username"],
                "uid": acc["uid"],
            },
        }
    )


@app.route("/api/logout", methods=["POST"])
def api_logout():
    session.clear()
    return jsonify({"status": "ok"})


@app.route("/api/me", methods=["GET"])
def api_me():
    uid = _current_uid()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    acc = _get_account(session.get("username"))
    return jsonify(
        {
            "status": "ok",
            "data": {
                "username": session.get("username"),
                "uid": uid,
                "uid_code": (acc.get("uid_code") or "") if acc else "",
            },
        }
    )


def _require_login():
    uid = _current_uid()
    if not uid:
        return None
    return uid


# ---------- 同步接口（仅本地插件调用） ----------


@app.route("/api/sync/push", methods=["POST"])
def sync_push():
    if not _check_sync_token():
        return jsonify({"status": "error", "message": "未授权"}), 401
    body = request.get_json(force=True, silent=True) or {}
    users = body.get("users") or []
    images = body.get("images") or []
    accounts = body.get("accounts") or []
    bind_requests = body.get("bind_requests") or []
    _save_snapshot(users, images, bind_requests=bind_requests)
    if accounts:
        _sync_accounts(accounts)
    return jsonify({"status": "ok"})


@app.route("/api/sync/pull_actions", methods=["GET"])
def sync_pull_actions():
    if not _check_sync_token():
        return jsonify({"status": "error", "message": "未授权"}), 401
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM pending_actions WHERE status='pending' ORDER BY created_at"
        ).fetchall()
    items = []
    for row in rows:
        item = {
            "id": row["id"],
            "type": row["type"],
            "payload": json.loads(row["payload"] or "{}"),
        }
        if row["type"] == "upload":
            item["upload"] = _upload_meta(row["payload"])
        items.append(item)
    return jsonify({"status": "ok", "actions": items})


def _upload_meta(payload: dict | str) -> dict | None:
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            payload = {}
    if not isinstance(payload, dict):
        payload = {}
    upload_id = payload.get("upload_id", "")
    if not upload_id:
        return None
    with _db() as conn:
        row = conn.execute("SELECT * FROM uploads WHERE id=?", (upload_id,)).fetchone()
    if not row:
        return None
    return {
        "id": row["id"],
        "owner_uid": row["owner_uid"],
        "filename": row["filename"],
        "public_url": row["public_url"],
        "size": row["size"],
        "created_at": row["created_at"],
    }


@app.route("/api/sync/resolve", methods=["POST"])
def sync_resolve():
    if not _check_sync_token():
        return jsonify({"status": "error", "message": "未授权"}), 401
    body = request.get_json(force=True, silent=True) or {}
    action_id = body.get("id", "")
    status = body.get("status", "failed")
    result = body.get("result", "")
    with _db() as conn:
        conn.execute(
            "UPDATE pending_actions SET status=?, result=? WHERE id=?",
            (status, json.dumps(result, ensure_ascii=False), action_id),
        )
    return jsonify({"status": "ok"})


# ---------- 公开只读：排行榜（不展示用户ID） ----------


@app.route("/api/leaderboard", methods=["GET"])
def api_leaderboard():
    snap = _load_snapshot()
    users = sorted(
        snap["users"],
        key=lambda u: int(u.get("points", 0) or 0),
        reverse=True,
    )
    limit = int(request.args.get("limit", 100))
    users = users[: max(1, min(limit, 500))]
    items = [
        {"rank": idx + 1, "name": u.get("user_name") or "匿名", "points": int(u.get("points", 0) or 0)}
        for idx, u in enumerate(users)
    ]
    return jsonify({"status": "ok", "data": {"items": items}})


# ---------- 登录后接口 ----------


@app.route("/api/me/points", methods=["GET"])
def api_me_points():
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    snap = _load_snapshot()
    for u in snap["users"]:
        if str(u.get("user_id", "")) == uid:
            return jsonify({"status": "ok", "data": {"found": True, "user": u}})
    return jsonify({"status": "ok", "data": {"found": False}})


@app.route("/api/me/images", methods=["GET"])
def api_me_images():
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    snap = _load_snapshot()
    images = [
        i
        for i in snap["images"]
        if str(i.get("owner_user_id", "")) == uid and i.get("url")
    ]
    images.sort(key=lambda i: i.get("created_at", 0) or 0, reverse=True)
    return jsonify(
        {"status": "ok", "data": {"total": len(images), "items": images}}
    )


@app.route("/api/me/redeem_result", methods=["GET"])
def api_me_redeem_result():
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    with _db() as conn:
        rows = conn.execute(
            "SELECT * FROM pending_actions WHERE type='redeem' "
            "ORDER BY created_at DESC LIMIT 20"
        ).fetchall()
    items = []
    for row in rows:
        payload = json.loads(row["payload"] or "{}")
        if str(payload.get("uid", "")) == uid:
            result = json.loads(row["result"] or "{}")
            items.append(
                {
                    "code": payload.get("code", ""),
                    "status": row["status"],
                    "message": result.get("message", ""),
                    "points": result.get("points", 0),
                    "created_at": row["created_at"],
                }
            )
    return jsonify({"status": "ok", "data": {"items": items}})


@app.route("/api/redeem", methods=["POST"])
def api_redeem():
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    body = request.get_json(force=True, silent=True) or {}
    code = str(body.get("code", "")).strip()
    if not code:
        return jsonify({"status": "error", "message": "请填写兑换码"}), 400
    action_id = uuid.uuid4().hex[:16]
    with _db() as conn:
        conn.execute(
            "INSERT INTO pending_actions (id, type, payload, status, created_at) "
            "VALUES (?, 'redeem', ?, 'pending', ?)",
            (
                action_id,
                json.dumps({"uid": uid, "code": code}, ensure_ascii=False),
                time.time(),
            ),
        )
    return jsonify(
        {
            "status": "ok",
            "message": "兑换申请已提交，积分到账前请等待数秒后刷新查询",
            "data": {"id": action_id},
        }
    )


@app.route("/api/upload", methods=["POST"])
def api_upload():
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    file = request.files.get("file")
    if not file or not file.filename:
        return jsonify({"status": "error", "message": "请选择图片"}), 400
    ext = os.path.splitext(file.filename)[1].lower() or ".png"
    upload_id = uuid.uuid4().hex[:12]
    filename = f"{upload_id}{ext}"
    file.save(os.path.join(UPLOAD_DIR, filename))
    size = os.path.getsize(os.path.join(UPLOAD_DIR, filename))
    public_url = f"{request.url_root.rstrip('/')}/static/uploads/{filename}"
    with _db() as conn:
        conn.execute(
            "INSERT INTO uploads (id, owner_uid, filename, public_url, size, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (upload_id, uid, filename, public_url, size, time.time()),
        )
        action_id = uuid.uuid4().hex[:16]
        conn.execute(
            "INSERT INTO pending_actions (id, type, payload, status, created_at) "
            "VALUES (?, 'upload', ?, 'pending', ?)",
            (
                action_id,
                json.dumps({"upload_id": upload_id}, ensure_ascii=False),
                time.time(),
            ),
        )
    return jsonify(
        {
            "status": "ok",
            "message": "图片已上传，正在同步，请稍后查看",
            "data": {"id": upload_id, "url": public_url},
        }
    )


@app.route("/static/uploads/<path:filename>")
def serve_upload(filename: str):
    return send_from_directory(UPLOAD_DIR, filename)


# ---------- 注册（cookieQQ 验证码） ----------


@app.route("/api/register", methods=["POST"])
def api_register():
    """注册：QQ号 + cookieQQ 验证码 + 用户名 + 密码。提交后由本地插件验证并创建账号。"""
    body = request.get_json(force=True, silent=True) or {}
    uid = str(body.get("uid", "")).strip()
    verify_id = str(body.get("verify_id", "")).strip()
    username = str(body.get("username", "")).strip()
    password = str(body.get("password", "")).strip()
    if not uid or not verify_id or not username or not password:
        return jsonify({"status": "error", "message": "请填写QQ号、cookieQQ验证码、用户名和密码"}), 400
    existing = _get_account(username)
    if existing is not None:
        return jsonify({"status": "error", "message": "该用户名已被注册，请换一个用户名"}), 400
    action_id = uuid.uuid4().hex[:16]
    with _db() as conn:
        conn.execute(
            "INSERT INTO pending_actions (id, type, payload, status, created_at) "
            "VALUES (?, 'register', ?, 'pending', ?)",
            (
                action_id,
                json.dumps(
                    {"uid": uid, "verify_id": verify_id, "username": username, "password": password},
                    ensure_ascii=False,
                ),
                time.time(),
            ),
        )
    return jsonify(
        {
            "status": "ok",
            "message": "注册申请已提交，校验通过后即可登录；登录后可在页面看到你的永久 UID",
            "data": {"id": action_id},
        }
    )


# ---------- 账号绑定（UID） ----------


@app.route("/api/me/bind_requests", methods=["GET"])
def api_bind_requests():
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    acc = _get_account(session.get("username"))
    code = str((acc or {}).get("uid_code", "") or "").strip()
    if not code:
        return jsonify({"status": "ok", "data": {"items": []}})
    snap = _load_snapshot()
    items = []
    for r in snap.get("bind_requests") or []:
        if str(r.get("target_uid", "")).strip() != code:
            continue
        items.append(
            {
                "key": r.get("key", ""),
                "platform": r.get("platform", ""),
                "user_id": r.get("user_id", ""),
                "user_name": r.get("user_name", ""),
                "status": r.get("status", ""),
                "updated_at": r.get("updated_at", 0),
            }
        )
    items.sort(key=lambda x: x.get("updated_at", 0), reverse=True)
    return jsonify({"status": "ok", "data": {"items": items}})


def _submit_bind_action(kind: str):
    uid = _require_login()
    if not uid:
        return jsonify({"status": "error", "message": "未登录"}), 401
    acc = _get_account(session.get("username"))
    code = str((acc or {}).get("uid_code", "") or "").strip()
    body = request.get_json(force=True, silent=True) or {}
    key = str(body.get("key", "")).strip()
    if not code or not key:
        return jsonify({"status": "error", "message": "参数缺失"}), 400
    snap = _load_snapshot()
    target = next(
        (r for r in (snap.get("bind_requests") or []) if str(r.get("key", "")) == key),
        None,
    )
    if target is None or str(target.get("target_uid", "")).strip() != code:
        return jsonify({"status": "error", "message": "找不到该请求，或它不属于你的 UID"}), 404
    action_id = uuid.uuid4().hex[:16]
    with _db() as conn:
        conn.execute(
            "INSERT INTO pending_actions (id, type, payload, status, created_at) "
            "VALUES (?, ?, ?, 'pending', ?)",
            (
                action_id,
                kind,
                json.dumps({"key": key, "uid_code": code}, ensure_ascii=False),
                time.time(),
            ),
        )
    return jsonify(
        {"status": "ok", "message": "已提交，稍后生效（约数秒）", "data": {"id": action_id}}
    )


@app.route("/api/me/bind/confirm", methods=["POST"])
def api_bind_confirm():
    return _submit_bind_action("bind_confirm")


@app.route("/api/me/bind/reject", methods=["POST"])
def api_bind_reject():
    return _submit_bind_action("bind_reject")


# ---------- 页面 ----------


@app.route("/")
def index():
    return render_template("index.html")


_init_db()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
